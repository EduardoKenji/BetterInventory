local AutoCrafter = {}

local mod
local controller
local panel

local function localize(setting_id, fallback)
	if not mod or type(mod.localize) ~= "function" then
		return fallback or setting_id
	end

	local ok, text = pcall(mod.localize, mod, setting_id)

	return ok and text or fallback or setting_id
end

local function setting(setting_id, default_value)
	if not mod or type(mod.get) ~= "function" then
		return default_value
	end

	local ok, value = pcall(mod.get, mod, setting_id)

	if not ok or value == nil then
		return default_value
	end

	return value
end

local function log(level, message)
	if not mod then
		return
	end

	local logger = mod[level]

	if type(logger) == "function" then
		pcall(logger, mod, message)
	end
end

local function notification_enabled()
	return setting("auto_crafter_show_probe_notifications", true) ~= false
end

local function notify(title, description)
	if not notification_enabled() then
		return false
	end

	local managers = rawget(_G, "Managers")
	local event_manager = managers and managers.event

	if not event_manager or type(event_manager.trigger) ~= "function" then
		return false
	end

	local ok = pcall(event_manager.trigger, event_manager, "event_add_notification_message", "custom", {
		line_1 = title,
		line_2 = description,
	})

	return ok
end

local function format_probe(snapshot)
	local store = snapshot and snapshot.store or {}
	local wallets = snapshot and snapshot.wallets or {}
	local currencies = wallets.currencies or {}
	local credits = currencies.credits and currencies.credits.amount
	local plasteel = currencies.plasteel and currencies.plasteel.amount
	local diamantine = currencies.diamantine and currencies.diamantine.amount

	return string.format(
		"Offers %s | Gear %s | Dockets %s | Plasteel %s | Diamantine %s",
		tostring(store.offer_count or 0),
		tostring((snapshot.gear and snapshot.gear.item_count) or 0),
		tostring(credits or "?"),
		tostring(plasteel or "?"),
		tostring(diamantine or "?")
	)
end

local function format_plan(plan)
	if not plan then
		return "Read-only planner is waiting for probe data."
	end

	local preflight = plan.preflight and plan.preflight.summary or "preflight unavailable"
	local estimate = plan.estimate and plan.estimate.summary or "estimate unavailable"

	return string.format("%s | %s | %s", preflight, estimate, plan.mode_note or "sequential requests")
end

local function format_catalog(catalog)
	if not catalog or catalog.available ~= true then
		return "Weapon trait discovery unavailable: " .. tostring(catalog and catalog.reason or "unknown reason")
	end

	return string.format(
		"Selected weapon catalogue | Perks %s | Blessings %s",
		tostring(catalog.perk_count or 0),
		tostring(catalog.blessing_count or 0)
	)
end

local function format_candidate(candidate)
	if not candidate then
		return "candidate unavailable"
	end

	return string.format(
		"%s | dump %s | gear %s",
		tostring(candidate.display_name or candidate.mastery_id or "weapon"),
		tostring(candidate.dump_stat or "?"),
		tostring(candidate.gear_id or "?")
	)
end

local function progress_milestone(value, interval)
	local count = tonumber(value) or 0

	return count == 1 or count > 0 and count % interval == 0
end

local function reporter(ui_panel)
	return {
		emit = function(_, kind, payload)
			if kind == "probe_started" then
				if ui_panel then
					ui_panel:set_phase("probe_inflight")
				end

				log("info", "Auto Crafter Helper read-only probe started.")
				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), localize("auto_crafter_probe_started", "Read-only probe started."))
			elseif kind == "probe_complete" then
				if ui_panel then
					ui_panel:set_phase("probe_complete", payload)
				end

				log("info", "Auto Crafter Helper read-only probe complete: " .. format_probe(payload))
				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), format_probe(payload))
			elseif kind == "probe_failed" then
				if ui_panel then
					ui_panel:set_phase("probe_failed")
				end

				log("error", "Auto Crafter Helper read-only probe failed: " .. tostring(payload and payload.error))
				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), string.format("%s: %s", localize("auto_crafter_probe_failed", "Read-only probe failed"), tostring(payload and payload.error)))
			elseif kind == "catalog_discovery_started" then
				if ui_panel then
					ui_panel:set_phase("trait_discovery")
				end

				log("info", "Auto Crafter Helper selected-weapon perk/blessing discovery started.")
			elseif kind == "catalog_discovery_complete" then
				if ui_panel then
					ui_panel:set_phase("probe_complete")
				end

				log("info", "Auto Crafter Helper " .. format_catalog(payload and payload.catalog))
				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), format_catalog(payload and payload.catalog))
			elseif kind == "catalog_discovery_failed" then
				if ui_panel then
					ui_panel:set_phase("trait_discovery_failed")
				end

				local discovery_error = payload and payload.error
				local message = discovery_error and "Weapon trait discovery unavailable: " .. tostring(discovery_error) or format_catalog(payload and payload.catalog)
				log("error", "Auto Crafter Helper " .. message)
				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), message)
			elseif kind == "plan_preview" then
				log("info", "Auto Crafter Helper read-only plan preview: " .. format_plan(payload and payload.plan))
				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), format_plan(payload and payload.plan))
			elseif kind == "mutation_blocked" then
				if ui_panel then
					ui_panel:set_phase("mutation_blocked")
				end

				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), "Mutation blocked: " .. tostring(payload and payload.reason or "preflight failed"))
			elseif kind == "purchase_search_started" then
				if ui_panel then
					ui_panel:set_phase(payload and payload.phase3 and "phase3_search_purchase" or "search_purchase")
				end

				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), payload and payload.phase3 and "Phase 3 serialized mastery search started." or "Serialized purchase search started.")
			elseif kind == "purchase_result" then
				if ui_panel then
					ui_panel:set_phase(payload and payload.search and payload.search.phase3 and "phase3_search_purchase" or "search_purchase")
				end

				local search = payload and payload.search or {}

				if progress_milestone(search.purchases, 10) then
					notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), string.format("Purchase %s/%s | %s | spent %s", tostring(search.purchases or "?"), tostring(search.max_purchases or "?"), format_candidate(payload and payload.candidate), tostring(search.spent or "?")))
				end
			elseif kind == "purchase_search_complete" then
				if ui_panel then
					ui_panel:set_phase("search_complete")
				end

				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), "Exact dump-stat candidate found: " .. format_candidate(payload and payload.candidate))
			elseif kind == "purchase_search_stopped" then
				if ui_panel then
					ui_panel:set_phase(tostring(payload and payload.reason or "search_stopped"))
				end

				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), "Purchase search stopped: " .. tostring(payload and payload.reason or "limit"))
			elseif kind == "phase3_fodder_started" then
				if ui_panel then
					ui_panel:set_phase("phase3_fodder_preflight")
				end

			elseif kind == "phase3_fodder_complete" then
				if ui_panel then
					ui_panel:set_phase("phase3_fodder_complete")
				end

				local fodder_payload = payload or {}

				if progress_milestone(fodder_payload.fodder_count, 5) then
					notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), "Phase 3: fodder sacrificed; mastery sync converged (" .. tostring(fodder_payload.fodder_count or "?") .. ").")
				end
			elseif kind == "phase3_complete" then
				if ui_panel then
					ui_panel:set_phase("phase3_complete")
				end

				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), "Phase 3 complete: target weapon preserved at mastery 20.")
			elseif kind == "phase3_stopped" then
				if ui_panel then
					ui_panel:set_phase(tostring(payload and payload.reason or "phase3_stopped"))
				end

				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), "Phase 3 stopped: " .. tostring(payload and payload.reason or "safety condition"))
			elseif kind == "mastery_operation_started" then
				if ui_panel then
					ui_panel:set_phase("mastery_preflight")
				end

				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), "Phase 2 started: " .. format_candidate(payload and payload.candidate))
			elseif kind == "mastery_upgrade_complete" or kind == "mastery_sacrifice_complete" or kind == "mastery_sync_started" or kind == "mastery_poll_result" or kind == "mastery_operation_complete" or kind == "mastery_sync_timeout" then
				if ui_panel then
					ui_panel:set_phase(kind)
				end

				if kind ~= "mastery_poll_result" then
					notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), "Phase 2 " .. string.gsub(kind, "_", " ") .. ".")
				end
			elseif kind == "operation_failed" then
				if ui_panel then
					ui_panel:set_phase("operation_failed")
				end

				log("error", "Auto Crafter Helper operation failed: " .. tostring(payload and payload.error))
				notify(localize("auto_crafter_notification_title", "Auto Crafter Helper"), "Operation failed: " .. tostring(payload and payload.error))
			elseif kind == "context_exit" then
				log("info", "Auto Crafter Helper stopped read-only work: " .. tostring(payload and payload.reason or "context exit"))
			end
		end,
	}
end

local function settings_adapter()
	return {
		get = function(_, setting_id)
			return setting(setting_id)
		end,
		set = function(_, setting_id, value)
			if not mod or type(mod.set) ~= "function" then
				return false
			end

			local ok = pcall(mod.set, mod, setting_id, value, false)

			return ok
		end,
	}
end

local function clock_adapter()
	return {
		now = function()
			local application = rawget(_G, "Application")

			if application and type(application.time_since_launch) == "function" then
				local ok, value = pcall(application.time_since_launch)

				return ok and value or nil
			end
		end,
	}
end

function AutoCrafter.configure(dependencies)
	dependencies = dependencies or {}
	mod = dependencies.mod or mod

	if not mod or type(mod.io_dofile) ~= "function" then
		log("error", "Auto Crafter Helper could not initialize: host mod loader unavailable.")

		return false
	end

	local ok_controller, Controller = pcall(mod.io_dofile, mod, "BetterInventory/scripts/mods/BetterInventory/auto_crafter/core/controller")
	local ok_planner, Planner = pcall(mod.io_dofile, mod, "BetterInventory/scripts/mods/BetterInventory/auto_crafter/core/planner")
	local ok_backend, Backend = pcall(mod.io_dofile, mod, "BetterInventory/scripts/mods/BetterInventory/auto_crafter/darktide/backend")
	local ok_context, Context = pcall(mod.io_dofile, mod, "BetterInventory/scripts/mods/BetterInventory/auto_crafter/darktide/context")
	local ok_panel, Panel = pcall(mod.io_dofile, mod, "BetterInventory/scripts/mods/BetterInventory/auto_crafter/darktide/panel")

	if not ok_controller or type(Controller) ~= "table" or type(Controller.new) ~= "function" then
		log("error", "Auto Crafter Helper controller unavailable; feature disabled.")

		return false
	end

	if not ok_planner or type(Planner) ~= "table" or type(Planner.build) ~= "function" then
		log("error", "Auto Crafter Helper planner unavailable; feature disabled.")

		return false
	end

	if not ok_backend or type(Backend) ~= "table" or type(Backend.new) ~= "function" then
		log("error", "Auto Crafter Helper backend unavailable; feature disabled.")

		return false
	end

	if not ok_context or type(Context) ~= "table" or type(Context.new) ~= "function" then
		log("error", "Auto Crafter Helper context adapter unavailable; feature disabled.")

		return false
	end

	if not ok_panel or type(Panel) ~= "table" or type(Panel.new) ~= "function" then
		log("error", "Auto Crafter Helper diagnostic panel unavailable; continuing without UI.")
		Panel = nil
	end

	local backend = Backend.new()
	local context = Context.new({
		is_brunt_view = dependencies.is_brunt_view,
	})

	panel = Panel and Panel.new({
		ViewElementGrid = dependencies.ViewElementGrid,
		get_selected_offer = dependencies.get_selected_offer,
		select_offer = dependencies.select_offer,
		settings = settings_adapter(),
		preview_plan = function()
			return controller and controller:preview_plan() or false
		end,
		start_purchase_search = function()
			return controller and controller:start_purchase_search() or false
		end,
		stop_active_run = function()
			return controller and controller:stop_active_run() or false
		end,
		localize = function(setting_id)
			return localize(setting_id, setting_id)
		end,
		logger = {
			info = function(_, message) log("info", message) end,
			error = function(_, message) log("error", message) end,
		},
	}) or nil

	controller = Controller.new({
		backend = backend,
		planner = Planner,
		context = context,
		get_selected_offer = dependencies.get_selected_offer,
		reporter = reporter(panel),
		logger = {
			info = function(_, message) log("info", message) end,
			error = function(_, message) log("error", message) end,
		},
		settings = settings_adapter(),
		clock = clock_adapter(),
	})

	return true
end

function AutoCrafter.on_brunt_view_ready(view)
	if not setting("auto_crafter_enable", false) then
		if panel then
			panel:detach()
		end

		return false
	end

	if panel then
		panel:attach(view)
	end

	return controller and controller:on_brunt_view_ready(view) or false
end

function AutoCrafter.on_view_closed(view)
	if panel then
		panel:detach()
	end

	return controller and controller:on_view_closed(view) or false
end

function AutoCrafter.on_context_exit(reason)
	if controller then
		controller:on_context_exit(reason)
	end

	if panel then
		panel:detach()
	end
end

function AutoCrafter.on_setting_changed(setting_id)
	if not setting("auto_crafter_enable", false) and panel then
		panel:detach()
	end

	return controller and controller:on_setting_changed(setting_id) or false
end

function AutoCrafter.update(dt)
	if panel then
		panel:update()
	end

	if controller then
		controller:update(dt)

		if panel and type(panel.sync_controller_snapshot) == "function" then
			panel:sync_controller_snapshot(controller:snapshot())
		end
	end
end

function AutoCrafter.snapshot()
	return controller and controller:snapshot() or {
		phase = "unavailable",
	}
end

function AutoCrafter.shutdown()
	if panel then
		panel:detach()
		panel = nil
	end

	if controller then
		controller:shutdown()
		controller = nil
	end
end

return AutoCrafter
